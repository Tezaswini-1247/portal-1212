 1  cd /stage_area/
    2  ls
    3  echo $HISTFILE
    4  ls -la ~/.bash_history
    5  cat /etc/passwd | cut -d: -f1
    6  sudo cat /home/visys/.bash_history
    7  sudo cat /home/username/.bash_history
    8  /var/log/history.log
    9  vi /u01/visys/reactjs_internal/
   10  cd /u01/visys/reactjs_internal/
   11  cat start_app.sh
   12  ls
   13  cd integrateddashboard/src/components/
   14  ls
   15  cp LoginForm.js LoginForm.js-org
   16  vi LoginForm.js
   17  sh /u01/visys/reactjs_internal/stop_app.sh
   18  sh /u01/visys/reactjs_internal/start_app.sh_app.sh
   19  sh /u01/visys/reactjs_internal/start_app.s
   20  sh /u01/visys/reactjs_internal/start_app.sh
   21  vi /u01/visys/reactjs_internal/start_app.sh
   22  sh /u01/visys/reactjs_internal/stop_app.sh
   23  vi /u01/visys/reactjs_internal/stop_app.sh
   24  vi /u01/visys/reactjs_internal/start_app.sh
   25  vi /u01/visys/reactjs_internal/stop_app.sh
   26  ps aux | grep node
   27  vi /u01/visys/reactjs_internal/start_app.sh
   28  sh /u01/visys/reactjs_internal/start_app.sh
   29  ps aux | grep node
   30  kill -9 1994497 1994519 1994531
   31  ps aux | grep npm
   32  sh /u01/visys/reactjs_internal/start_app.sh
   33  vi LoginForm.js
   34  ps aux | grep npm
   35  kill -9 1994613
   36  ps aux | grep node
   37  kill -9 1994604 1994626 1994638
   38  sh /u01/visys/reactjs_internal/start_app.sh
   39  sudo netstat -tuln | grep :5000
   40  sudo lsof -i :5000
   41  vi /u01/visys/reactjs_internal/stop_app.sh
   42  sh /u01/visys/reactjs_internal/stop_app.sh
   43  sudo lsof -i :5000
   44  sh /u01/visys/reactjs_internal/start_app.sh
   45  vi LoginForm.js
   46  vi LoginForm.js-org
   47  vi /u01/visys/reactjs_internal/Backend/.env
   48  vi LoginForm.js
   49  sh /u01/visys/reactjs_internal/stop_app.sh
   50  sh /u01/visys/reactjs_internal/start_app.sh
   51  vi LoginForm.js
   52  sh /u01/visys/reactjs_internal/stop_app.sh
   53  sh /u01/visys/reactjs_internal/start_app.sh
   54  vi LoginForm.js-org
   55  vi LoginForm.js
   56  sh /u01/visys/reactjs_internal/stop_app.sh
   57  sh /u01/visys/reactjs_internal/start_app.sh
   58  vi LoginForm.js
   59  sh /u01/visys/reactjs_internal/stop_app.sh
   60  sh /u01/visys/reactjs_internal/start_app.sh
   61  vi LoginForm.js-org
   62  vi LoginForm.js
   63  sh /u01/visys/reactjs_internal/stop_app.sh
   64  sh /u01/visys/reactjs_internal/start_app.sh
   65  vi LoginForm.js
   66  sh /u01/visys/reactjs_internal/stop_app.sh
   67  sh /u01/visys/reactjs_internal/start_app.sh
   68  vi LoginForm.js
   69  sh /u01/visys/reactjs_internal/stop_app.sh
   70  sh /u01/visys/reactjs_internal/start_app.sh
   71  vi LoginForm.js
   72  sh /u01/visys/reactjs_internal/stop_app.sh
   73  sh /u01/visys/reactjs_internal/start_app.sh
   74  vi LoginForm.js
   75  sh /u01/visys/reactjs_internal/start_app.sh
   76  sh /u01/visys/reactjs_internal/stop_app.sh
   77  sh /u01/visys/reactjs_internal/start_app.sh
   78  vi LoginForm.js
   79  sh /u01/visys/reactjs_internal/start_app.sh
   80  sh /u01/visys/reactjs_internal/stop_app.sh
   81  sh /u01/visys/reactjs_internal/start_app.sh
   82  vi LoginForm.js
   83  sh /u01/visys/reactjs_internal/stop_app.sh
   84  sh /u01/visys/reactjs_internal/start_app.sh
   85  vi LoginForm.js
   86  rm -rf LoginForm.js
   87  cp LoginForm.js-org LoginForm.js
   88  sh /u01/visys/reactjs_internal/stop_app.sh
   89  sh /u01/visys/reactjs_internal/start_app.sh
   90  vi LoginForm.js
   91  sh /u01/visys/reactjs_internal/stop_app.sh
   92  sh /u01/visys/reactjs_internal/start_app.sh
   93  vi LoginForm.js
   94  rm -rf LoginForm.js
   95  cp LoginForm.js-org LoginForm.js
   96  sh /u01/visys/reactjs_internal/stop_app.sh
   97  sh /u01/visys/reactjs_internal/start_app.sh
   98  ll
   99  cd uo1
  100  cd /uo1
  101  cd /uo1/visys/react.js_internal
  102  cd npm
  103  cd npm/
  104  cd .npm/
  105  ll
  106  cd ..
  107  ls -ltr
  108  cd .vim/
  109  ll
  110  cd ..
  111  cd /u01/visys/reactjs_internal
  112  ll
  113  sh start_app.sh
  114  cd /u01/visys/reactjs_internal/integrateddashboard/src/components
  115  ls
  116  vi LoginForm.js
  117  sh /u01/visys/reactjs_internal/stop_app.sh
  118  sh /u01/visys/reactjs_internal/start_app.sh
  119  vi /u01/visys/reactjs_internal/Backend/.env
  120  sh /u01/visys/reactjs_internal/stop_app.sh
  121  sh /u01/visys/reactjs_internal/start_app.sh
  122  vi LoginForm.js
  123  sh /u01/visys/reactjs_internal/stop_app.sh
  124  sh /u01/visys/reactjs_internal/start_app.sh
  125  rm -rf LoginForm.js
  126  cp LoginForm.js-org LoginForm.js
  127  sh /u01/visys/reactjs_internal/stop_app.sh
  128  sh /u01/visys/reactjs_internal/start_app.sh
  129  vi LoginForm.js
  130  sh /u01/visys/reactjs_internal/stop_app.sh
  131  sh /u01/visys/reactjs_internal/start_app.sh
  132  vi LoginForm.js
  133  vi /u01/visys/reactjs_internal/Backend/.env
  134  vi LoginForm.js
  135  sh /u01/visys/reactjs_internal/stop_app.sh
  136  sh /u01/visys/reactjs_internal/start_app.sh
  137  vi LoginForm.js
  138  sh /u01/visys/reactjs_internal/stop_app.sh
  139  sh /u01/visys/reactjs_internal/start_app.sh
  140  vi LoginForm.js
  141  rm -rf LoginForm.js
  142  cp LoginForm.js-org LoginForm.js
  143  vi LoginForm.js
  144  sh /u01/visys/reactjs_internal/stop_app.sh
  145  sh /u01/visys/reactjs_internal/start_app.sh
  146  cd ..
  147  cd..
  148  ls
  149  cd ..
  150  ls
  151  cd node_modules/webpack-dev-server/
  152  cd client/clients/
  153  ls
  154  vi WebSocketClient.js
  155  clear
  156  cd /u01/visys/reactjs_internal
  157  sh stop_app.sh
  158  cd /stage_area
  159  git clone https://github.com/Tezaswini-1247/react-project.git
  160  l
  161  cd forms/  react-project/
  162  cd /forms
  163  cd forms/
  164  l
  165  cd 'react project'/
  166  l
  167  ll
  168  cd ../../'react project'/
  169  cd ../../react-project/
  170  l
  171  cd ../../u01/visys/reactjs_internal
  172  ll
  173  rm -rf Backend/ integrateddashboard/
  174  ll
  175  cd ../../../stage_area
  176  rm -rf form/
  177  rm -rf forms/
  178  ll
  179  pwd
  180  cp /stage_area /u01/visys/reactjs_internal
  181  cp -p  /stage_area /u01/visys/reactjs_internal
  182  cp -p  /stage_area/ /u01/visys/reactjs_internal
  183  cp -pr  /stage_area/ /u01/visys/reactjs_internal
  184  cd
  185  cd /u01/visys/reactjs_internal
  186  ll
  187  rm stage_area
  188  rm stage_area/~
  189  rm stage_area/
  190  rm -rf stage_area/
  191  ll
  192  cd
  193  cd /stage_area/
  194  ll
  195  cd react-project/
  196  ll
  197  cp -pr Backend_app/ node_modules/
  198  sample_app/ /u01/visys/reactjs_internal
  199  cp -pr Backend_app/ node_modules/ sample_app/ /u01/visys/reactjs_internal
  200  cd
  201  cd /u01/visys/reactjs_internal
  202  ll
  203  sh start_app.sh
  204  vi start_app.sh
  205  vi  stop_app.sh
  206  sh start_app.sh
  207  cd sample_app/
  208  ll
  209  vi .env
  210  cd src/
  211  ll
  212  view components
  213  cd components/
  214  ll
  215  vi Loginform/
  216  cd Loginform
  217  =ll
  218  ll
  219  vi Loginform.jsx
  220  cd ../../../..
  221  vi  stop_app.sh
  222  sh stop_app.sh
  223  sh start_app.sh
  224  ll
  225  cd sample_app
  226  ll
  227  vi .env
  228  cd /..
  229  cd /u01/visys/reactjs_internal/
  230  sh start_app.sh
  231  vi .env
  232  ll
  233  cd sample_app
  234  ll
  235  vi .env
  236  cd ..
  237  sh start_app.sh
  238  sh stop_app.sh
  239  sh start_app.sh
  240  hostname -I
  241  ll
  242  rm -rf node_modules/
  243  ll
  244  cd sample_app
  245  npm start
  246  cd ..
  247  sh stop_app.sh
  248  cd sample_app
  249  npm start
  250  cd /u01/visys/reactjs_internal/
  251  ll
  252  cd Backend_app/
  253  ll
  254  node server.js
  255  pwd
  256  df -kh
  257  pwd
  258  df -kh
  259  ls -ltr /home/*
  260  cat /etc/passwd
  261  su - visys
  262  mkdir -p /home/visys
  263  id visys
  264  chown -R visys:visys /home/visys
  265  su - visys
  266  df -kh
  267  ps -aef |grep -i npm
  268  apt install nodejs
  269  node --version
  270  apt upgrade nodejs
  271  apt-get update
  272  apt-get install nginx
  273  nginx -v
  274  nginx
  275  nginx -t
  276  cat /etc/nginx/nginx.con
  277  nginx
  278  netstat -nap |grep -i 80
  279  nginx stop
  280  nginx -s
  281  systemctl stop nginx
  282  systemctl status nginx
  283  systemctl start nginx
  284  systemctl status nginx
  285  pwd
  286  df -kh
  287  mkdir -p /u01/visys/reactjs_internal
  288  cd /u01/visys/reactjs_internal/
  289  pwd
  290  npm install
  291  apt install npm
  292  npm -v
  293  pm2 -v
  294  pm2 status app.js
  295  pm2 staty app.js
  296  pm2 start app.js
  297  ls -ltr
  298  ls
  299  pwd
  300  ls -ltr
  301  cp /tmp/myapp.war .
  302  ls -ltr
  303  jar -xvf myapp.war .
  304  pwd
  305  ls -ltt
  306  apt install default-jdk
  307  jar -xvf myapp.war .
  308  ls -ltr
  309  jar xf myapp.war
  310  ls -ltrh myapp.war
  311  pwd
  312  ls -ltr
  313  pwd
  314  ls -ltrh
  315  cd META-INF/
  316  ls
  317  cd ..
  318  pwd
  319  rm -rf META-INF
  320  unzip myapp.war
  321  ls -lt
  322  apt install unzip
  323  unzip myapp.war
  324  apt upgrade
  325  apt upgrade kernel
  326  apt -f install
  327  apt install java
  328  apt install jdk
  329  apt upgrade jdk
  330  apt upgrade jar
  331  apt uninstall jar
  332  apt remove jar
  333  apt remove jdk
  334  apt install openjdk-21-jdk-headless
  335  jar -xvf myapp.war
  336  df -kh
  337  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
  338  source ~/.bashrc
  339  nvm install node
  340  nvm use node
  341  sudo apt update
  342  sudo apt install git
  343  sudo apt update
  344  sudo apt install git
  345  npm install
  346  pwd
  347  mkdir -p /u01/stage_area
  348  df -kh
  349  mkdir -p /stage_area
  350  chmod -R 777 /stage_area
  351  pwd
  352  ls
  353  cd integrateddashboard/
  354  ls
  355  ls -ltr
  356  cd src/components/
  357  ls
  358  view LoginForm.js
  359  curl -v X GET http://localhost:5000/api/login
  360  pwd
  361  cd ../..
  362  pwd
  363  cd ..
  364  pwd
  365  ls
  366  ls -ltr
  367  cd Backend/
  368  ls
  369  ls -ltr
  370  view server.js
  371  pwd
  372  find . -name login
  373  view server.js
  374  cd /u01/
  375  ls
  376  cd visys/
  377  mkdir pagadmin
  378  mv pagadmin pgadmin
  379  cd pgadmin/
  380  apt install pgadmin4
  381  sudo apt install pgadmin4
  382  sudo apt install pgadmin
  383  uname -a
  384  cat /etc/resolv.conf
  385  curl https://www.pgadmin.org/static/packages_pgadmin_org.pub | sudo apt-key add
  386  sudo sh -c 'echo "deb https://ftp.postgresql.org/pub/pgadmin/pgadmin4/apt/$(lsb_release -cs) pgadmin4 main" > /etc/apt/sources.list.d/pgadmin4.list && apt update'
  387  apt install pgadmin4
  388  sudo /usr/pgadmin4/bin/setup-web.sh
  389  pwd
  390  cd ..
  391  ls
  392  cd reactjs_internal/integrateddashboard/
  393  ls
  394  cd src/
  395  ls
  396  sl -tlr
  397  cd components/
  398  ls -ltr
  399  view LoginForm.css
  400  view LoginForm.js
  401  grep LoginForm.js *.*
  402  grep -i LoginForm.js *.*
  403  view LoginForm.js
  404  cat /etc/hosts
  405  curl -v telnet://localhost:5000
  406  cd /u01/visys/reactjs_internal/Backend/node_modules/
  407  ls
  408  ls -ltr
  409  cd ..
  410  ls
  411  ls -ltr
  412  view package.json
  413  pwd
  414  view package.json
  415  ps -aef |grep -i 5000
  416  netstat -nap |grep -i 5000
  417  ps -aef |grep 1978490
  418  kill -9 1978490
  419  pwd
  420  ls -ltr
  421  pwd
  422  history |grep node
  423  node server.js
  424  view server.js
  425  node server.js
  426  npm install cors
  427  node server.js
  428  which node
  429  file node
  430  file /root/.nvm/versions/node/v22.9.0/bin/node
  431  strace -e write=all -e all node server.js
  432  node server.js
  433  pwd
  434  sl -ltr
  435  pwd
  436  ls -ltr
  437  vi server.js
  438  node server.js
  439  netstat -nap |grep 5000
  440  netstat -nap |grep 5000|grep LISTEN
  441  netstat -nap |grep 5000|grep LISTEN|awk {'print $NF'}
  442  netstat -nap |grep 5000|grep LISTEN|awk {'print $NF'}|cut -d"/" -f1
  443  vi pwd
  444  pwd
  445  cd ../integrateddashboard/
  446  ls
  447  sl -tlr
  448  ls -ltr
  449  view package.json
  450  grep Login.css *
  451  pwd
  452  ls -ltr
  453  cd src/
  454  ls
  455  ls -ltr
  456  view App.js
  457  npm start
  458  cd ../
  459  pwd
  460  cd Backend/
  461  ls
  462  view server.js
  463  ls
  464  cd ../integrateddashboard/
  465  ls
  466  ls -ltr
  467  pwd
  468  npm start
  469  pwd
  470  ls
  471  npm start
  472  pwd
  473  ls -ltr
  474  cd src/
  475  ls -ltr
  476  cd components/
  477  ls -ltr
  478  pwd
  479  cd ..
  480  ls -ltr
  481  pwd
  482  cd components/
  483  ls
  484  ls -tlr
  485  view LoginForm.js
  486  grep 'localhost:5000' *.*
  487  sed -i 's|localhost:5000|49.13.164.196:5000|g' *.*
  488  grep 'localhost:5000' *.*
  489  npm startt
  490  npm start
  491  pwd
  492  ls -ltr
  493  view LoginForm.js
  494  sed -i 's|49.13.164.196:5000|localhost:5000|g' *.*
  495  view LoginForm.js
  496  npm start
  497  history |grep sed
  498  vi LoginForm.css
  499  vi LoginForm.js
  500  sed -i 's|localhost:5000|49.13.164.196:5000|g' *.*
  501  npm start
  502  pwd
  503  ls -ltr
  504  cd ..
  505  pwd
  506  ls -ltr
  507  npm start
  508  pwd
  509  cd /u01/visys/reactjs_internal/
  510  ls
  511  ls -ltr
  512  pwd
  513  mkdir log
  514  pwd
  515  cd log/
  516  pwd
  517  cd ..
  518  pwd
  519  ls ltr
  520  pwd
  521  sl -ltr
  522  ls -ltrd /u01/visys/reactjs_internal/*
  523  vi start_app.sh
  524  sh start_app.sh
  525  ps -fu $USER
  526  pwd
  527  cd log/
  528  ls
  529  ls -ltr
  530  view int_dashboard_npm.out
  531  view int_dashboard_node.out
  532  pwd
  533  ls -ltr
  534  pwd
  535  cd ..
  536  ls -ltr
  537  cp -pr start_app.sh stop_app.sh
  538  view stop_app.sh
  539  sh stop_app.sh
  540  ls -ltr
  541  vi start_app.sh
  542  sh start_app.sh
  543  pwd
  544  ls -ltr
  545  pwd
  546  ls -ltr
  547  cd /stage_area/
  548  ls
  549  pwd
  550  history |grep sed
  551  pwd
  552  cd /u01/visys/reactjs_internal/integrateddashboard/
  553  ls -ltr
  554  cd src/
  555  ls
  556  ls -ltr
  557  grep 5000 *.*
  558  history |grep sed
  559  sed -i 's|49.13.164.196|portal.cloud4coolkids.com|g'
  560  sed -i 's|49.13.164.196|portal.cloud4coolkids.com|g' *.*
  561  sed -i 's|localhost|portal.cloud4coolkids.com|g' *.*
  562  history |grep sed
  563  cd /u01/app/
  564  ls
  565  cd /u01/visys/reactjs_internal/
  566  ls
  567  sh stop_app.sh
  568  sh start_app.sh
  569  pwd
  570  ls -ltr
  571  date
  572  cd Backend/
  573  ls
  574  ls -latr
  575  cat .env
  576  pwd
  577  view server.js
  578  pwd
  579  echo apple |base64
  580  echo YXBwbGUK|base64 -d
  581  pwd
  582  ls -ltr
  583  pwd
  584  cd /u01/visys/
  585  ls
  586  cd reactjs_internal/
  587  ls
  588  ls -ltr
  589  cd Backend_app/
  590  ls
  591  ls -ltr
  592  view server.js
  593  pwd
  594  netstat -nap |grep 5000
  595  netstat -nap |grep 3000
  596  pwd
  597  cd ../sample_app/
  598  ls
  599  ls -ltr
  600  cd src/
  601  ls
  602  ls -ltr
  603  cd components/
  604  ls -ltr
  605  view Loginform/Loginform.jsx
  606  pwd
  607  ls -latr
  608  pwd
  609  cd ../..
  610  pwd
  611  ls -ltr
  612  cat .env
  613  pwd
  614  cd ..
  615  ls -ltr
  616  pwd
  617  cat start_app.sh
  618  cd /u01/visys/reactjs_internal/log
  619  ls -ltr
  620  cat int_dashboard_stop_npm.err
  621  pwd
  622  cd ..
  623  sl -ltr
  624  ls -ltr
  625  cat stop_app.sh
  626  sh stop_app.sh
  627  ps -fu $USER
  628  ls -ltr
  629  pwd
  630  sh start_app.sh
  631  netstat -nap |grep 3000
  632  cat start_app.sh
  633  cd /u01/visys/reactjs_internal/sample_app
  634  npm start
  635  view npm
  636  which npm
  637  strace -e write=all -e all npm start
  638  npm -i
  639  npm i
  640  npm start
  641  pwd
  642  ls -latr
  643  view .env
  644  cd ..
  645  sh stop_app.sh
  646  sh start_app.sh
  647  pwd
  648  ls -ltr
  649  pwd
  650  cd sample_app/src/components/
  651  ks ktr
  652  ls -ltr
  653  view Loginform/Loginform.jsx
  654  #${apiUrl}
  655  cp -pr /u01/visys/reactjs_internal /u01/visys/reactjs_internal_bak1
  656  sed -i 's|${apiUrl}|http://49.13.164.196:5000|g' *
  657  pwd
  658  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*
  659  cd ~
  660  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i 's|${apiUrl}|http://49.13.164.196:5000|g' *; done
  661  ls -ltr
  662  pwd
  663  cd -
  664  ls -ltr
  665  cd Loginform/
  666  view Loginform.jsx
  667  pwd
  668  cd ..
  669  grep -iR '`' *
  670  cd ~
  671  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i 's|`|'|g' *; done
  672  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i 's#`#'#g' *; done
  673  sed -i "s|`|'|g" institutionform/InstitutionForm.js
  674  sed -i "s/\`/\'|g" institutionform/InstitutionForm.js
  675  sed -i "s/\`/\'/g" institutionform/InstitutionForm.js
  676  pwd
  677  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i "s/\`/\'/g"  *; done
  678  cd -
  679  view Loginform/Loginform.jsx
  680  pwd
  681  cd ../..
  682  pwd
  683  ls
  684  cd ..
  685  ls -ltr
  686  pwd
  687  sh stop_app.sh
  688  sh start_app.sh
  689  pwd
  690  ls -ltr
  691  cd sample_app/
  692  ls
  693  sl -ltr
  694  ls -ltr
  695  pwd
  696  view src/components/Loginform/Loginform.jsx
  697  pwd
  698  cd ..
  699  grep -iR 'portal' *.*
  700  grep -iR 'portal' *
  701  grep -iR 'coolkids' *
  702  grep -iR 'portal.cloud4coolkids' *
  703  pwd
  704  cd sample_app/
  705  ls
  706  ls -ltr
  707  vi .env
  708  pwd
  709  view src/components/Loginform/Loginform.jsx
  710  view src/components/Loginform/Loginform.jsx
  711  pwd
  712  cd ../Backend_app/
  713  ls -ltr
  714  pwd
  715  view package.json
  716  pwd
  717  view package.json
  718  view server.js
  719  pwd
  720  cd ..
  721  ls
  722  ls -ltr
  723  pwd
  724  cd sample_app/src/components/
  725  ls
  726  view Loginform/Loginform.jsx
  727  pwd
  728  cd ~
  729  pwd
  730  cd /u01/visys/reactjs_internal/
  731  sh stop_app.sh
  732  sh start_app.sh
  733  grep -iR 'http://49.13.164.196:5000/api/login' *
  734  grep -iRl 'http://49.13.164.196:5000/api/login' *
  735  view sample_app/node_modules/.cache/babel-loader/69cc3f221105f87c83573eb3b40be14514b8b0021be40d0ba2adb89243d1228c.json
  736  sh stop_app.sh
  737  rm sample_app/node_modules/.cache/babel-loader/69cc3f221105f87c83573eb3b40be14514b8b0021be40d0ba2adb89243d1228c.json sample_app/node_modules/.cache/babel-loader/a08cee4283986cc1fbd7ce52ec2315e05a1fe3f5f744c89dea8cbec1b34f65ae.json
  738  view sample_app/node_modules/.cache/default-development/1.pack
  739  rm sample_app/node_modules/.cache/default-development/1.pack
  740  sh start_app.sh
  741  grep -iRl 'http://49.13.164.196:5000/api/login' *
  742  kill -9 1977719
  743  pwd
  744  cd /u01/visys/reactjs_internal/integrateddashboard/
  745  ls
  746  ls -ltr
  747  npm status
  748  npm help
  749  npm test
  750  npm start
  751  netstat -nap |grep 3000
  752  ps -aef |grep 1977743
  753  kill -9 1977743
  754  netstat -nap |grep 3000
  755  npm start
  756  pwd
  757  cd /var/log/
  758  slk kr
  759  ks 0ktr
  760  ls -ltr
  761  pwd
  762  cd -
  763  ls -ltr
  764  pwd
  765  cd ../Backend/
  766  ls
  767  ls -ltr
  768  view server.js
  769  pwd
  770  cd ../integrateddashboard/
  771  ls
  772  ls -ltr
  773  cd src/
  774  ls
  775  ls -ltr
  776  view components/LoginForm.js
  777  netstat -nap |grep 5000
  778  curl -c telnet://localhost:5000
  779  curl -v telnet://localhost:5000
  780  view components/LoginForm.js
  781  pwd
  782  view ../../Backend/server.js
  783  pwd
  784  cd ..
  785  ls
  786  npm start
  787  npm install cors
  788  npm start
  789  bash
  790  cd /u01/visys/reactjs_internal~
  791  cd u01/visys/reactjs_internal~
  792  ll
  793  cd /u01/visys/reactjs_internal
  794  ll
  795  vi start_app.sh
  796  vi stop_app.sh
  797  cd /u01/visys/reactjs_internal
  798  ll
  799  cd sample_app/
  800  ll
  801  cd src/
  802  ll
  803  vi App.css
  804  cd ../
  805  ll
  806  cd  public/
  807  ll
  808  vi  index.html
  809  cd ../
  810  sh stop_app.sh
  811  sh start_app.sh
  812  passwd root
  813  pwd
  814  df -kh
  815  uptime
  816  df -kh
  817  ps -aef
  818  useradd visys
  819  passwd visys
  820  vi /etc/sudoers
  821  useradd -m itadmin
  822  usermod -aG sudo itadmin
  823  passwd itadmin
  824  history
  825  ls /opt/
  826  ls
  827  systemctl status apach
  828  pwd
  829  cd /u01/visys/reactjs_internal
  830  ls
  831  sh stop_app.sh
  832  sh start_app.sh
  833  pwd
  834  cd sample_app/
  835  ls
  836  cd src/components/
  837  ls -ltr
  838  pwd
  839  ls -ltr *.*
  840  ls -ltr */*.*
  841  view studentloginform/studentloginform.jsx
  842  cat studentloginform/studentloginform.jsx |more
  843  pwd
  844  cd ../..
  845  pwd
  846  cd ../Backend_app/node_modules/
  847  ls -ltr
  848  pwd
  849  cd ../..
  850  pwd
  851  ls -ltr
  852  cd Backend_app/
  853  ls
  854  ls -ltr
  855  pwd
  856  ls -ltr
  857  cat server.js |more
  858  cd /u01/visys/reactjs_internal
  859  ll
  860  rm -rf  Backend_app/
  861  ll
  862  rm -rf sample_app/
  863  ll
  864  rm -rfsample_app/
  865  rm -rf sample_app/
  866  ll
  867  cd ../../
  868  cd ../
  869  cd
  870  cd /stage_area
  871  ll
  872  cd react-project/
  873  ll
  874  rm -rf *
  875  ll
  876  cd ../
  877  git clone https://github.com/Tezaswini-1247/react-project.git
  878  ll
  879  rm -rf react-project/
  880  ll
  881  git clone https://github.com/Tezaswini-1247/react-project.git
  882  ll
  883  cd
  884  cd stage_area/
  885  cd /stage_area
  886  ll
  887  cd react-project/
 888  ll
  889  cd ../../
  890  cd /u01/visys/reactjs_internal
  891  ll
  892  cd
  893  cp -pr Backend_app/ /u01/visys/reactjs_internal
  894  cd /stage_area
  895  cp -pr Backend_app/ /u01/visys/reactjs_internal
  896  ll
  897  cd react-project/
  898  cp -pr Backend_app/ /u01/visys/reactjs_internal
  899  ll
  900  cp -pr sample_app/ /u01/visys/reactjs_internal
  901  cd
  902  cd /u01/visys/reactjs_internal
  903  ll
  904  cd sample_app/
  905  ll
  906  vi .env
  907  cd ../
  908  cd Backend_app/
  909  vi .env
  910  cd
  911  cd /u01/visys/reactjs_internal
  912  ll
  913  start_app.sh
  914  sh start_app.sh
  915  node server.js
  916  cd Backend_app/
  917  node server.js
  918  cd ../
  919  sh stop_app.sh
  920  cd Backend_app/
  921  node server.js
  922  netstat -nap |grep 5000
  923  cd ../
  924  sh start_app.sh
  925  netstat -nap |grep 5000
  926  cd sample_app
  927  ll
  928  cd src/
  929  ll
  930  cd components/
  931  ll
  932  cd
  933  cd /u01/visys/reactjs_internal/sample_app/src/components#
  934  cd
  935  cd /u01/visys/reactjs_internal/sample_app/src/components
  936  ll
  937  cd Loginform/
  938  ll
  939  vi Loginform.jsx
  940  cd ../
  941  sh stop_app.sh
  942  sh start_app.sh
  943  cd /sample_app/src/components
  944  cd sample_app/src/components/
  945  sed -i 's|${apiUrl}|http://49.13.164.196:5000|g' *
  946  cd
  947  ls -ltrd /u01/visys/reactjs_internal# cd sample_app/src/components/*|awk {'print $NF'} | while read DIR do  cd ${DIR}; sed -i 's|${apiUrl}|http://49.13.164.196:5000|g' *; done
  948  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'} | while read DIR; do cd ${DIR}; sed -i 's|${apiUrl}|http://49.13.164.196:5000|g' *; done
  949  cd /u01/visys/reactjs_internal
  950  ll
  951  cd sample_app/
  952  ll
  953  cd src/
  954  ll
  955  cd components/
  956  ll
  957  cd followupform/
  958  ll
  959  vi FollowupForm.js
  960  cd ../../../
  961  cd components/
  962  ll
  963  cd src/
  964  ll
  965  cd components/
  966  sed -i 's|`|'|g'
do
  967  sed -i 's|`|'|g' *
do
  968  ls -ltrd /u01/visys/reactjs_internal# cd sample_app/src/components/*|awk {'print $NF'} | while read DIR
do cd ${DIR}; sed -i 's|`|'|g' *
done
done
  969  cd
  970  cd /u01/visys/reactjs_internal/sample_app/src/components
  971  ll
  972  cd followupform/
  973  ll
  974  vi FollowupForm.js
  975  cd
  976  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i 's|`|'|g' *; done
  977  cd /u01/visys/reactjs_internal/sample_app/src/components/followupform
  978  ll
  979  vi FollowupForm.js
  980  cd
  981  ls -ltrd /u01/visys/reactjs_internal/sample_app/src/components/*|awk {'print $NF'}|while read DIR; do cd ${DIR}; sed -i "s/\`/\'/g"  *; done
  982  cd /u01/visys/reactjs_internal/sample_app/src/components/followupform
  983  ll
  984  vi FollowupForm.js
  985  cd ../../
  986  cd ../
  987  sh stop_app.sh
  988  cd ../
  989  sh stop_app.sh
  990  sh start_app.sh
  991  history
